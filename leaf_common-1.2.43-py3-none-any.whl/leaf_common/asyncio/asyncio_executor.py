
# Copyright © 2019-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
"""
See class comment for details.
"""
from typing import Any
from typing import Awaitable
from typing import Callable
from typing import Dict
from typing import List
from typing import Tuple

import asyncio
import functools
import inspect
import logging
import threading
import traceback

from asyncio import AbstractEventLoop
from asyncio import Future
from asyncio import Task
from concurrent import futures

from leaf_common.asyncio.event_loop_factory import EventLoopFactory
from leaf_common.asyncio.task_executor import TaskExecutor
from leaf_common.asyncio.asyncio_threadpool_executor import AsyncioThreadPoolExecutor

EXECUTOR_START_TIMEOUT_SECONDS: int = 5


class AsyncioExecutor(TaskExecutor):
    """
    Class for managing asynchronous background tasks in a single thread
    Riffed from:
    https://stackoverflow.com/questions/38387443/how-to-implement-a-async-grpc-python-server/63020796#63020796
    """

    # pylint: disable=too-many-instance-attributes
    def __init__(self):
        """
        Constructor
        """
        super().__init__()
        self._shutdown: bool = False
        self._thread: threading.Thread = None
        # We are going to start new thread for this Executor,
        # so we need a new event loop bound to this particular thread:
        self._threadpool_executor: AsyncioThreadPoolExecutor = AsyncioThreadPoolExecutor()
        self._loop: AbstractEventLoop = EventLoopFactory.new_event_loop()
        self._loop.set_exception_handler(AsyncioExecutor.loop_exception_handler)
        self._loop.set_default_executor(self._threadpool_executor)
        self._loop_ready = threading.Event()
        self._init_done = threading.Event()
        self._background_tasks: Dict[int, Dict[str, Any]] = {}
        # background tasks table will be accessed from different threads,
        # so protect it:
        self._background_tasks_lock = threading.Lock()
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_event_loop(self) -> AbstractEventLoop:
        """
        :return: The AbstractEventLoop associated with this instance
        """
        return self._loop

    def start(self):
        """
        Starts the background thread.
        Do this separately from constructor for more control.
        """
        # Don't start twice
        if self._thread is not None:
            return

        self._thread = threading.Thread(target=self.loop_manager,
                                        args=(self._loop, self._loop_ready),
                                        daemon=True)
        self._thread.start()
        timeout: int = EXECUTOR_START_TIMEOUT_SECONDS
        was_set: bool = self._loop_ready.wait(timeout=timeout)
        if not was_set:
            raise ValueError(f"FAILED to start executor event loop in {timeout} sec")

    def initialize(self, init_function: Callable):
        """
        Call initializing function on executor event loop
        and wait for it to finish.
        :param init_function: function to call.
        """
        if self._shutdown:
            raise RuntimeError("Cannot schedule new calls after shutdown")
        if not self._loop.is_running():
            raise RuntimeError("Loop must be started before any function can "
                               "be submitted")
        self._init_done.clear()
        self._loop.call_soon_threadsafe(self.run_initialization, init_function, self._init_done)
        timeout: int = EXECUTOR_START_TIMEOUT_SECONDS
        was_set: bool = self._init_done.wait(timeout=timeout)
        if not was_set:
            raise ValueError(f"FAILED to run executor initializer in {timeout} sec")

    @staticmethod
    def run_initialization(init_function: Callable, init_done: threading.Event):
        """
        Run in-loop initialization
        """
        try:
            init_function()
        except Exception as exc:  # pylint: disable=broad-except
            print(f"Initializing function raised exception: {exc}")
        finally:
            init_done.set()

    @staticmethod
    def notify_loop_ready(loop_ready: threading.Event):
        """
        Function will be called once the event loop starts
        """
        loop_ready.set()

    @staticmethod
    def loop_manager(loop: AbstractEventLoop, loop_ready: threading.Event):
        """
        Entry point static method for the background thread.

        :param loop: The AbstractEventLoop to use to run the event loop.
        :param loop_ready: event notifying that loop is ready for execution.
        """
        asyncio.set_event_loop(loop)
        loop.call_soon(AsyncioExecutor.notify_loop_ready, loop_ready)
        loop.run_forever()

        # If we reach here, the loop was stopped.
        # We should gather any remaining tasks and finish them.
        pending = asyncio.all_tasks(loop=loop)
        if pending:
            # We want all possibly pending tasks to execute -
            # don't need them to raise exceptions.
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        # Close the event loop to free its related resources
        loop.close()

    @staticmethod
    def loop_exception_handler(loop: AbstractEventLoop, context: Dict[str, Any]):
        """
        Handles exceptions for the asyncio event loop

        DEF - I believe this exception handler is for exceptions that happen in
              the event loop itself, *not* the submit()-ed coroutines.
              Exceptions from the coroutines are handled by submission_done() below.

        :param loop: The asyncio event loop
        :param context: A context dictionary described here:
                https://docs.python.org/3/library/asyncio-eventloop.html#asyncio.loop.call_exception_handler
        """
        # Call the default exception handler first
        loop.default_exception_handler(context)

        message = context.get("message", None)
        exception = context.get("exception", None)
        formatted_exception = traceback.format_exception(exception)
        print(f"Event loop traceback ({message}):\n{formatted_exception}")

    def get_function_name(self, function, submitter_id: str) -> str:
        """
        :param function: The function handle
        :param submitter_id: A string id denoting who is doing the submitting
        :return: The fully qualified name of the function, suitable for logging/tracking
        """
        function_name: str = None
        try:
            function_name = function.__qualname__  # Fully qualified name of function
        except AttributeError:
            # Just get the class name
            function_name = function.__class__.__name__
        if submitter_id:
            function_name = f"{submitter_id}:{function_name}"
        return function_name

    def _in_executor_thread(self) -> bool:
        """
        :return: True if we are currently executing in the event loop thread.
        """
        return threading.get_ident() == self._thread.ident

    def _create_in_loop_thread(
            self, function, task_name: str, task_creation_future: futures.Future, /, *args, **kwargs) -> None:
        """
        Create a task in the event loop thread and set it as a result on the provided Future.
        :param function: The function handle to run
        :param task_name: The name to assign to the task
        :param task_creation_future: The Future to set result/exception on
        :param /: Positional or keyword arguments.
            See https://realpython.com/python-asterisk-and-slash-special-parameters/
        :param args: args for the function
        :param kwargs: keyword args for the function
        """
        try:
            if inspect.isawaitable(function):
                task = self._loop.create_task(function, name=task_name)
            elif inspect.iscoroutinefunction(function):
                # function is async def -> create task for its coroutine
                coro = function(*args, **kwargs)
                task = self._loop.create_task(coro, name=task_name)
            else:
                # function is sync -> run it in a worker thread, but task lives in event loop
                func = functools.partial(function, *args, **kwargs)
                task = self._loop.create_task(asyncio.to_thread(func), name=task_name)
            task_creation_future.set_result(task)
        except BaseException as exc:  # pylint: disable=broad-except
            task_creation_future.set_exception(exc)

    def _submit_as_task(self, submitter_id: str, function, /, *args, **kwargs) -> futures.Future:
        """
        Submit some executable item as a Task in executor event loop.
        If call is from the outside of AsyncioExecutor running thread,
        we should do it by scheduling a "task creation" task on internal event loop,
        and then get a Future representing this creation task.
        The result of this Future successful completion will be a Task object we have created.
        If call is from the inside of AsyncioExecutor running thread, we can just create the Task directly
        and set it as a result on the Future we will return to the caller.

        :param submitter_id: A string id denoting who is doing the submitting.
        :param function: The function handle to run
        :param /: Positional or keyword arguments.
            See https://realpython.com/python-asterisk-and-slash-special-parameters/
        :param args: args for the function
        :param kwargs: keyword args for the function
        :return: A Future object which will return a created Task in our event loop.
        """
        task_creation_future: futures.Future = futures.Future()
        task_name: str = self.get_function_name(function, submitter_id)
        if self._in_executor_thread():
            # We are already in the event loop thread:
            self._create_in_loop_thread(function, task_name, task_creation_future, *args, **kwargs)
            # We should have already set the result on the task_creation_future, so just return it:
            return task_creation_future

        # If we are not in the event loop thread,
        # we need to schedule a task to create the resulting Task in the event loop thread.
        # Construct a partial function to create the task:
        creation_function = functools.partial(self._create_in_loop_thread,
                                              function, task_name,
                                              task_creation_future,
                                              *args, **kwargs)
        # Ensure task is created in the event loop thread
        self._loop.call_soon_threadsafe(creation_function)
        return task_creation_future

    def submit(self, submitter_id: str, function, /, *args, **kwargs) -> Task:
        """
        Submit a function to be run in the asyncio event loop.

        :param submitter_id: A string id denoting who is doing the submitting.
        :param function: The function handle to run
        :param /: Positional or keyword arguments.
            See https://realpython.com/python-asterisk-and-slash-special-parameters/
        :param args: args for the function
        :param kwargs: keyword args for the function
        :return: An asyncio.Task that corresponds to the submitted task
        """
        if self._shutdown:
            raise RuntimeError("Cannot schedule new tasks after shutdown")

        if not self._loop.is_running():
            raise RuntimeError("Loop must be started before any function can "
                               "be submitted")

        # The execution logic here looks like this:
        # Call the helper method -> get a Future back ->
        # block until task submitted to internal event loop runs and creates our Task ->
        # get this Task as a result of Future happening.
        task_creation_future: futures.Future = self._submit_as_task(submitter_id, function, *args, **kwargs)
        # Wait for task to be created in event loop thread (blocking calling thread)
        task: Task = task_creation_future.result()

        self.track_task(task)
        return task

    def create_task(self, awaitable: Awaitable, submitter_id: str, raise_exception: bool = False) -> Future:
        """
        Creates a task for the event loop given an Awaitable
        :param awaitable: The Awaitable to create and schedule a task for
        :param submitter_id: A string id denoting who is doing the submitting.
        :param raise_exception: True if exceptions are to be raised in the executor.
                    Default is False.
        :return: The Task object bound to our event loop
        """
        if self._shutdown:
            raise RuntimeError("Cannot schedule new tasks after shutdown")

        if not self._loop.is_running():
            raise RuntimeError("Loop must be started before any function can "
                               "be submitted")

        # self._submit_as_task will handle the logic of whether we are in the event loop thread or not.
        task_creation_future: futures.Future = self._submit_as_task(submitter_id, awaitable)
        # Wait for task to be created and returned as the result of the Future (blocking calling thread)
        task: Task = task_creation_future.result()
        self.track_task(task, raise_exception=raise_exception)
        return task

    def track_task(self, task: Task, raise_exception: bool = False):
        """
        :param task: The task to track
        :param raise_exception: True if exceptions are to be raised in the executor.
                    Default is False.
        """

        # Weak references in the asyncio system can cause tasks to disappear
        # before they execute.  Hold a reference in a global as per
        # https://docs.python.org/3/library/asyncio-task.html#creating-tasks

        task_info_dict: Dict[str, Any] = {
            "task": task,
            "raise_exception": raise_exception
        }
        task_id = id(task)
        self._background_tasks[task_id] = task_info_dict
        task.add_done_callback(self.submission_done)
        return task

    @staticmethod
    async def _cancel_and_drain(tasks: List[Future]):
        # Request cancellation for tasks that are not already done:
        pending = []
        for task in tasks:
            if not task.done():
                task.cancel("cancel-and-drain")
                pending.append(task)
        # Don't raise exceptions in the tasks being cancelled -
        # we don't really need to react to them.
        _ = await asyncio.gather(*pending, return_exceptions=True)

    def cancel_current_tasks(self, timeout: float = 5.0):
        """
        Method to cancel the currently submitted tasks for this executor.
        :param timeout: The maximum time in seconds to cancel the current tasks
        """
        if not self._loop.is_running():
            raise RuntimeError("Loop must be running to cancel remaining tasks")
        tasks_to_cancel: List[Task] = []

        with self._background_tasks_lock:
            # Clear the background tasks map
            # and allow next tasks (if any) to be added.
            # Currently present tasks will be cancelled below.
            background_tasks_save: Dict[int, Dict[str, Any]] = self._background_tasks
            self._background_tasks = {}

        for task_dict in background_tasks_save.values():
            task: Task = task_dict.get("task", None)
            if task and not task.done():
                tasks_to_cancel.append(task)
        cancel_task = asyncio.run_coroutine_threadsafe(AsyncioExecutor._cancel_and_drain(tasks_to_cancel), self._loop)
        try:
            cancel_task.result(timeout)
        except futures.TimeoutError:
            self.logger.info("Timeout %f sec exceeded while cleaning up AsyncioExecutor %s", timeout, id(self))
            raise

    def _check_task(self, task: Task):
        """
        Check status of a task.
        :param task: The Task to check
        """
        task_id: int = id(task)
        if not task.done():
            # Something is very wrong if we get here:
            # submission_done() must only be called when task is done in some way.
            raise RuntimeError(f"Task {task_id} is not done, but submission_done is called.")
        if not isinstance(task, Task):
            # We only register this callback on Tasks, so this is unexpected.
            raise RuntimeError(f"Future {task_id} is expected to be Task.")

        origination: str = task.get_name()
        if task_id not in self._background_tasks:
            # That could happen if the task is being cancelled by us,
            # and background tasks table is already cleared.
            self.logger.info("Task %s/%s is not present in the tasks table.", task_id, origination)

    def submission_done(self, task: Task):
        """
        Intended as a "done_callback" method on tasks created by submit() above.
        Does some processing on a task that has been marked as done
        (for whatever reason).

        :param task: The Task which has completed
        """

        # Get a dictionary entry describing some metadata about the future itself.
        task_id: int = id(task)
        task_info: Dict[str, Any] = {}
        task_info = self._background_tasks.get(task_id, task_info)

        self._check_task(task)
        origination: str = task.get_name()

        try:
            # First see if there was any exception,
            # note that if the task was cancelled,
            # calling task.exception() itself raises CancelledError.
            # But it will be handled below in general exception handler.
            exception = task.exception()
            if exception is not None and task_info.get("raise_exception"):
                raise exception

            # If we want to quietly ignore any possible task exception,
            # we can retrieve the result only if exception is absent,
            # to avoid exception re-raising right here:
            if exception is None:
                result = task.result()
                _ = result

        except StopAsyncIteration:
            # StopAsyncIteration is OK
            pass

        except futures.TimeoutError:
            self.logger.info("Task from %s took too long", origination)

        except asyncio.exceptions.CancelledError:
            # Cancelled task is OK - it may happen for different reasons.
            self.logger.info("Task from %s was cancelled", origination)

        # pylint: disable=broad-exception-caught
        except Exception as exc:
            formatted_exception: List[str] = traceback.format_exception(exc)
            for line in formatted_exception:
                if line.endswith("\n"):
                    line = line[:-1]
                self.logger.info("%s", line)

        # As a last gesture, remove the background task from the map
        # we use to keep its reference around. Do it safely:
        with self._background_tasks_lock:
            self._background_tasks.pop(task_id, None)

    def get_threads_metrics(self) -> Tuple[int, int]:
        """
        For ThreadExecutorPool used by our event loop,
        get number of created threads and number of currently running threads.
         :return: Tuple of (number of threads in the pool, number of currently running threads)
        """
        if self._threadpool_executor:
            return self._threadpool_executor.get_threads_metrics()
        return 0, 0

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False):
        """
        Shuts down the event loop.

        :param wait: True if we should wait for the background thread to join up.
                     False otherwise.  Default is True.
        :param cancel_futures: Ignored? Default is False.
        """
        # Here is an outline of how this call works:
        # 1. shutdown() tells event loop to stop
        # (telling loop to execute loop.stop(), and doing this from caller thread by call_soon_threadsafe())
        #  then it starts to wait to join executor thread;
        # 2. executor thread returns from loop.run_forever(), because event loop has stopped,
        # does some finishing with outstanding loop tasks, and closes the loop. Then executor thread finishes.
        # Note that closing event loop frees loop-bound resources which otherwise
        # are not necessarily released.
        # 3. shutdown() joins the finished executor thread and peacefully finishes itself.
        # 4. shutdown() call returns to caller.
        self._shutdown = True
        self._loop.call_soon_threadsafe(self._loop.stop)
        if wait:
            self._thread.join()
        self._thread = None
